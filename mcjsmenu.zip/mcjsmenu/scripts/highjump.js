// прыжок каждые 2 секунды (пример использования player.jump)
var t = 0;
registerTick(function () { if (++t % 40 === 0) player.jump(); });
