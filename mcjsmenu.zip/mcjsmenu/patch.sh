#!/bin/sh
# 1) сборка:   ndk-build            -> libs/armeabi-v7a/libmcjsmenu.so
# 2) положить libmcjsmenu.so в lib/armeabi-v7a/ рядом с libminecraftpe.so внутри APK
# 3) добавить зависимость, чтобы игра загрузила мод сама:
patchelf --add-needed libmcjsmenu.so libminecraftpe.so
# 4) собрать APK обратно и подписать (MT Manager / apksigner)
