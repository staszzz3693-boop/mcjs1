// mcjsmenu: мод-меню с загрузкой .js скриптов для Minecraft PE 1.1.5 (armeabi-v7a)
// Хуки без inline-библиотек:
//   1) vtable LocalPlayer[31] = normalTick  -> тик игры, тут выполняется JS
//   2) GOT eglSwapBuffers                   -> рисуем меню
//   3) GOT AInputQueue_getEvent             -> тапы по меню
#include <jni.h>
#include <dlfcn.h>
#include <link.h>
#include <elf.h>
#include <sys/mman.h>
#include <unistd.h>
#include <dirent.h>
#include <sys/stat.h>
#include <ctype.h>
#include <pthread.h>
#include <string.h>
#include <stdio.h>
#include <android/log.h>
#include <android/input.h>
#include <EGL/egl.h>
#include <GLES2/gl2.h>
#include <string>
#include <vector>
#include <mutex>
#include <algorithm>

extern "C" {
#include "quickjs.h"
}

#define TAG "mcjsmenu"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)
static const char* LIB = "libminecraftpe.so";
static const char* SCRIPT_DIR = "/sdcard/games/com.mojang/mcjs";

// ---------------------------------------------------------------- GOT / vtable
static bool unprotect(void* addr) {
    long ps = sysconf(_SC_PAGESIZE);
    uintptr_t p = (uintptr_t)addr & ~(ps - 1);
    return mprotect((void*)p, ps * 2, PROT_READ | PROT_WRITE) == 0;
}

struct ModInfo { uintptr_t base; const ElfW(Phdr)* ph; int n; };
static int phdrCb(struct dl_phdr_info* i, size_t, void* d) {
    if (i->dlpi_name && strstr(i->dlpi_name, LIB)) {
        ModInfo* m = (ModInfo*)d; m->base = i->dlpi_addr; m->ph = i->dlpi_phdr; m->n = i->dlpi_phnum; return 1;
    }
    return 0;
}

// Подменяет все GOT-записи символа sym в libminecraftpe.so. Возвращает оригинал.
static void* patchGot(const char* sym, void* newFn) {
    ModInfo m = {0, 0, 0};
    dl_iterate_phdr(phdrCb, &m);
    if (!m.base) return nullptr;
    const ElfW(Dyn)* dyn = nullptr;
    for (int i = 0; i < m.n; i++)
        if (m.ph[i].p_type == PT_DYNAMIC) dyn = (const ElfW(Dyn)*)(m.base + m.ph[i].p_vaddr);
    if (!dyn) return nullptr;
    uintptr_t jmprel = 0, rel = 0, symtab = 0, strtab = 0; size_t pltsz = 0, relsz = 0;
    auto fix = [&](uintptr_t v) { return v < m.base ? v + m.base : v; };  // разные линкеры по-разному
    for (; dyn->d_tag != DT_NULL; dyn++) {
        switch (dyn->d_tag) {
            case DT_JMPREL: jmprel = fix(dyn->d_un.d_ptr); break;
            case DT_PLTRELSZ: pltsz = dyn->d_un.d_val; break;
            case DT_REL: rel = fix(dyn->d_un.d_ptr); break;
            case DT_RELSZ: relsz = dyn->d_un.d_val; break;
            case DT_SYMTAB: symtab = fix(dyn->d_un.d_ptr); break;
            case DT_STRTAB: strtab = fix(dyn->d_un.d_ptr); break;
        }
    }
    void* orig = nullptr;
    auto scan = [&](uintptr_t tbl, size_t sz) {
        for (size_t i = 0; i < sz / sizeof(Elf32_Rel); i++) {
            const Elf32_Rel* r = (const Elf32_Rel*)tbl + i;
            unsigned t = ELF32_R_TYPE(r->r_info);
            if (t != R_ARM_JUMP_SLOT && t != R_ARM_GLOB_DAT && t != R_ARM_ABS32) continue;
            const Elf32_Sym* s = (const Elf32_Sym*)symtab + ELF32_R_SYM(r->r_info);
            if (strcmp((const char*)strtab + s->st_name, sym) != 0) continue;
            void** slot = (void**)(m.base + r->r_offset);
            if (!unprotect(slot)) continue;
            if (!orig) orig = *slot;
            *slot = newFn;
        }
    };
    if (jmprel) scan(jmprel, pltsz);
    if (rel) scan(rel, relsz);
    return orig;
}

// ---------------------------------------------------------------- игровое API
typedef void (*tick_t)(void*);
typedef void (*setpos_t)(void*, const float*);
typedef const float* (*getpos_t)(const void*);
typedef void (*jump_t)(void*);

static tick_t origTick;
static setpos_t gSetPos;
static getpos_t gGetPos;
static jump_t gJump;
static void* gPlayer;  // LocalPlayer*, обновляется каждый тик

// ---------------------------------------------------------------- скрипты
struct Script {
    std::string name, path;
    bool wanted = false, active = false;
    std::vector<JSValue> ticks;
};
static std::vector<Script> gScripts;
static std::mutex gMx;
static bool gRescan = true;
static JSRuntime* gRt;
static JSContext* gCtx;
static int gCur = -1;  // индекс скрипта, который сейчас выполняется

static JSValue js_log(JSContext* c, JSValueConst, int argc, JSValueConst* argv) {
    for (int i = 0; i < argc; i++) {
        const char* s = JS_ToCString(c, argv[i]);
        if (s) { LOGI("[js] %s", s); JS_FreeCString(c, s); }
    }
    return JS_UNDEFINED;
}
static JSValue js_registerTick(JSContext* c, JSValueConst, int argc, JSValueConst* argv) {
    if (argc > 0 && JS_IsFunction(c, argv[0]) && gCur >= 0)
        gScripts[gCur].ticks.push_back(JS_DupValue(c, argv[0]));
    return JS_UNDEFINED;
}
static JSValue js_getPos(JSContext* c, JSValueConst, int, JSValueConst*) {
    JSValue a = JS_NewArray(c);
    if (gPlayer && gGetPos) {
        const float* p = gGetPos(gPlayer);
        for (int i = 0; i < 3; i++) JS_SetPropertyUint32(c, a, i, JS_NewFloat64(c, p[i]));
    }
    return a;
}
static JSValue js_setPos(JSContext* c, JSValueConst, int argc, JSValueConst* argv) {
    if (argc < 3 || !gPlayer || !gSetPos) return JS_UNDEFINED;
    double d[3];
    for (int i = 0; i < 3; i++) JS_ToFloat64(c, &d[i], argv[i]);
    float v[3] = {(float)d[0], (float)d[1], (float)d[2]};
    gSetPos(gPlayer, v);
    return JS_UNDEFINED;
}
static JSValue js_jump(JSContext*, JSValueConst, int, JSValueConst*) {
    if (gPlayer && gJump) gJump(gPlayer);
    return JS_UNDEFINED;
}

static void initJs() {
    gRt = JS_NewRuntime();
    gCtx = JS_NewContext(gRt);
    JSValue g = JS_GetGlobalObject(gCtx);
    JS_SetPropertyStr(gCtx, g, "log", JS_NewCFunction(gCtx, js_log, "log", 1));
    JS_SetPropertyStr(gCtx, g, "registerTick", JS_NewCFunction(gCtx, js_registerTick, "registerTick", 1));
    JSValue pl = JS_NewObject(gCtx);
    JS_SetPropertyStr(gCtx, pl, "getPos", JS_NewCFunction(gCtx, js_getPos, "getPos", 0));
    JS_SetPropertyStr(gCtx, pl, "setPos", JS_NewCFunction(gCtx, js_setPos, "setPos", 3));
    JS_SetPropertyStr(gCtx, pl, "jump", JS_NewCFunction(gCtx, js_jump, "jump", 0));
    JS_SetPropertyStr(gCtx, g, "player", pl);
    JS_FreeValue(gCtx, g);
}

static void reportError() {
    JSValue e = JS_GetException(gCtx);
    const char* s = JS_ToCString(gCtx, e);
    LOGI("[js error] %s", s ? s : "?");
    if (s) JS_FreeCString(gCtx, s);
    JS_FreeValue(gCtx, e);
}

static void rescan() {  // gMx захвачен
    mkdir(SCRIPT_DIR, 0777);
    std::vector<Script> fresh;
    if (DIR* d = opendir(SCRIPT_DIR)) {
        while (dirent* e = readdir(d)) {
            std::string n = e->d_name;
            if (n.size() > 3 && n.substr(n.size() - 3) == ".js") {
                Script s; s.name = n; s.path = std::string(SCRIPT_DIR) + "/" + n;
                for (auto& o : gScripts) if (o.name == n) { s = o; break; }
                fresh.push_back(s);
            }
        }
        closedir(d);
    }
    for (auto& o : gScripts) {  // выгрузить пропавшие/перезагрузить
        bool keep = false; for (auto& f : fresh) if (f.name == o.name) keep = true;
        if (!keep) for (auto& v : o.ticks) JS_FreeValue(gCtx, v);
    }
    std::sort(fresh.begin(), fresh.end(), [](const Script& a, const Script& b) { return a.name < b.name; });
    gScripts.swap(fresh);
}

static void loadScript(int i) {
    Script& s = gScripts[i];
    FILE* f = fopen(s.path.c_str(), "rb");
    if (!f) { LOGI("cannot open %s", s.path.c_str()); s.wanted = false; return; }
    std::string src; char buf[4096]; size_t n;
    while ((n = fread(buf, 1, sizeof buf, f)) > 0) src.append(buf, n);
    fclose(f);
    gCur = i;
    JSValue r = JS_Eval(gCtx, src.c_str(), src.size(), s.name.c_str(), JS_EVAL_TYPE_GLOBAL);
    if (JS_IsException(r)) { reportError(); s.wanted = false; }
    else s.active = true;
    JS_FreeValue(gCtx, r);
    gCur = -1;
}
static void unloadScript(int i) {
    for (auto& v : gScripts[i].ticks) JS_FreeValue(gCtx, v);
    gScripts[i].ticks.clear();
    gScripts[i].active = false;
}

static void hookedTick(void* self) {
    origTick(self);
    gPlayer = self;
    std::lock_guard<std::mutex> lk(gMx);
    if (!gCtx) initJs();
    if (gRescan) { rescan(); gRescan = false; }
    for (size_t i = 0; i < gScripts.size(); i++) {
        Script& s = gScripts[i];
        if (s.wanted && !s.active) loadScript((int)i);
        else if (!s.wanted && s.active) unloadScript((int)i);
        if (!s.active) continue;
        gCur = (int)i;
        for (auto& fn : s.ticks) {
            JSValue r = JS_Call(gCtx, fn, JS_UNDEFINED, 0, nullptr);
            if (JS_IsException(r)) { reportError(); s.wanted = false; }
            JS_FreeValue(gCtx, r);
        }
        gCur = -1;
    }
}

// ---------------------------------------------------------------- GL оверлей
static const struct { char c; unsigned char b[5]; } FONT[] = {
 {'0',{0x3E,0x51,0x49,0x45,0x3E}},{'1',{0x00,0x42,0x7F,0x40,0x00}},{'2',{0x42,0x61,0x51,0x49,0x46}},
 {'3',{0x21,0x41,0x45,0x4B,0x31}},{'4',{0x18,0x14,0x12,0x7F,0x10}},{'5',{0x27,0x45,0x45,0x45,0x39}},
 {'6',{0x3C,0x4A,0x49,0x49,0x30}},{'7',{0x01,0x71,0x09,0x05,0x03}},{'8',{0x36,0x49,0x49,0x49,0x36}},
 {'9',{0x06,0x49,0x49,0x29,0x1E}},{'A',{0x7E,0x11,0x11,0x11,0x7E}},{'B',{0x7F,0x49,0x49,0x49,0x36}},
 {'C',{0x3E,0x41,0x41,0x41,0x22}},{'D',{0x7F,0x41,0x41,0x22,0x1C}},{'E',{0x7F,0x49,0x49,0x49,0x41}},
 {'F',{0x7F,0x09,0x09,0x09,0x01}},{'G',{0x3E,0x41,0x49,0x49,0x7A}},{'H',{0x7F,0x08,0x08,0x08,0x7F}},
 {'I',{0x00,0x41,0x7F,0x41,0x00}},{'J',{0x20,0x40,0x41,0x3F,0x01}},{'K',{0x7F,0x08,0x14,0x22,0x41}},
 {'L',{0x7F,0x40,0x40,0x40,0x40}},{'M',{0x7F,0x02,0x0C,0x02,0x7F}},{'N',{0x7F,0x04,0x08,0x10,0x7F}},
 {'O',{0x3E,0x41,0x41,0x41,0x3E}},{'P',{0x7F,0x09,0x09,0x09,0x06}},{'Q',{0x3E,0x41,0x51,0x21,0x5E}},
 {'R',{0x7F,0x09,0x19,0x29,0x46}},{'S',{0x46,0x49,0x49,0x49,0x31}},{'T',{0x01,0x01,0x7F,0x01,0x01}},
 {'U',{0x3F,0x40,0x40,0x40,0x3F}},{'V',{0x1F,0x20,0x40,0x20,0x1F}},{'W',{0x3F,0x40,0x38,0x40,0x3F}},
 {'X',{0x63,0x14,0x08,0x14,0x63}},{'Y',{0x07,0x08,0x70,0x08,0x07}},{'Z',{0x61,0x51,0x49,0x45,0x43}},
 {'.',{0x00,0x60,0x60,0x00,0x00}},{'-',{0x08,0x08,0x08,0x08,0x08}},{'_',{0x40,0x40,0x40,0x40,0x40}},
 {':',{0x00,0x36,0x36,0x00,0x00}},{'[',{0x00,0x7F,0x41,0x41,0x00}},{']',{0x00,0x41,0x41,0x7F,0x00}},
};

typedef EGLBoolean (*swap_t)(EGLDisplay, EGLSurface);
static swap_t origSwap;
static bool gOpen = false;
static int gW = 1, gH = 1;
static float gSc = 1;  // масштаб UI
static GLuint gProg; static GLint aPos, uScr, uCol;

static void initGL() {
    const char* vs = "attribute vec2 p;uniform vec2 s;void main(){gl_Position=vec4(p.x/s.x*2.-1.,1.-p.y/s.y*2.,0.,1.);}";
    const char* fs = "precision mediump float;uniform vec4 c;void main(){gl_FragColor=c;}";
    GLuint v = glCreateShader(GL_VERTEX_SHADER); glShaderSource(v, 1, &vs, 0); glCompileShader(v);
    GLuint f = glCreateShader(GL_FRAGMENT_SHADER); glShaderSource(f, 1, &fs, 0); glCompileShader(f);
    gProg = glCreateProgram(); glAttachShader(gProg, v); glAttachShader(gProg, f); glLinkProgram(gProg);
    aPos = glGetAttribLocation(gProg, "p"); uScr = glGetUniformLocation(gProg, "s"); uCol = glGetUniformLocation(gProg, "c");
}

static std::vector<float> gBatch;
static void quad(float x, float y, float w, float h) {
    float v[12] = {x,y, x+w,y, x,y+h, x+w,y, x+w,y+h, x,y+h};
    gBatch.insert(gBatch.end(), v, v + 12);
}
static void flush(float r, float g, float b, float a) {
    if (gBatch.empty()) return;
    glUniform4f(uCol, r, g, b, a);
    glVertexAttribPointer(aPos, 2, GL_FLOAT, GL_FALSE, 0, gBatch.data());
    glDrawArrays(GL_TRIANGLES, 0, (GLsizei)(gBatch.size() / 2));
    gBatch.clear();
}
static void text(const std::string& s, float x, float y, float px) {
    for (char ch : s) {
        ch = (char)toupper((unsigned char)ch);
        for (auto& g : FONT) if (g.c == ch)
            for (int col = 0; col < 5; col++)
                for (int row = 0; row < 7; row++)
                    if (g.b[col] & (1 << row)) quad(x + col * px, y + row * px, px, px);
        x += 6 * px;
    }
}

// геометрия меню (в пикселях)
static float btnW() { return 56 * gSc; }
static float btnH() { return 28 * gSc; }
static float rowH() { return 28 * gSc; }
static float panW() { return 280 * gSc; }
static float panX() { return 10 * gSc; }
static float panY() { return 10 * gSc + btnH() + 4 * gSc; }

static void drawMenu() {
    float px = std::max(1.0f, 2.0f * gSc);
    quad(10 * gSc, 10 * gSc, btnW(), btnH()); flush(0.1f, 0.1f, 0.1f, 0.8f);
    text("JS", 10 * gSc + 8 * gSc, 10 * gSc + 6 * gSc, px); flush(1, 1, 1, 1);
    if (!gOpen) return;
    std::lock_guard<std::mutex> lk(gMx);
    int rows = 1 + (int)gScripts.size();
    quad(panX(), panY(), panW(), rows * rowH()); flush(0.05f, 0.05f, 0.05f, 0.85f);
    text("RELOAD LIST", panX() + 8 * gSc, panY() + 7 * gSc, px); flush(1, 0.9f, 0.3f, 1);
    for (size_t i = 0; i < gScripts.size(); i++) {
        float y = panY() + (i + 1) * rowH();
        text(std::string(gScripts[i].wanted ? "[X] " : "[ ] ") + gScripts[i].name, panX() + 8 * gSc, y + 7 * gSc, px);
        flush(gScripts[i].wanted ? 0.4f : 0.85f, gScripts[i].wanted ? 1.0f : 0.85f, gScripts[i].wanted ? 0.4f : 0.85f, 1);
    }
}

static EGLBoolean hookedSwap(EGLDisplay d, EGLSurface s) {
    eglQuerySurface(d, s, EGL_WIDTH, &gW); eglQuerySurface(d, s, EGL_HEIGHT, &gH);
    gSc = std::max(1.0f, gH / 360.0f);
    GLint prog, abuf, en, vp[4]; GLboolean blend = glIsEnabled(GL_BLEND), depth = glIsEnabled(GL_DEPTH_TEST),
        cull = glIsEnabled(GL_CULL_FACE), scis = glIsEnabled(GL_SCISSOR_TEST);
    glGetIntegerv(GL_CURRENT_PROGRAM, &prog); glGetIntegerv(GL_ARRAY_BUFFER_BINDING, &abuf);
    glGetIntegerv(GL_VIEWPORT, vp);
    if (!gProg) initGL();
    glUseProgram(gProg); glBindBuffer(GL_ARRAY_BUFFER, 0);
    glGetVertexAttribiv(aPos, GL_VERTEX_ATTRIB_ARRAY_ENABLED, &en);
    glDisable(GL_DEPTH_TEST); glDisable(GL_CULL_FACE); glDisable(GL_SCISSOR_TEST);
    glEnable(GL_BLEND); glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glViewport(0, 0, gW, gH);
    glUniform2f(uScr, (float)gW, (float)gH);
    glEnableVertexAttribArray(aPos);
    drawMenu();
    if (!en) glDisableVertexAttribArray(aPos);
    glViewport(vp[0], vp[1], vp[2], vp[3]);
    glBindBuffer(GL_ARRAY_BUFFER, abuf); glUseProgram(prog);
    if (!blend) glDisable(GL_BLEND); if (depth) glEnable(GL_DEPTH_TEST);
    if (cull) glEnable(GL_CULL_FACE); if (scis) glEnable(GL_SCISSOR_TEST);
    return origSwap(d, s);
}

// ---------------------------------------------------------------- ввод
typedef int32_t (*getev_t)(AInputQueue*, AInputEvent**);
static getev_t origGetEvent;
static bool gConsuming = false;

static bool handleTap(float x, float y) {
    float bx = 10 * gSc, by = 10 * gSc;
    if (x >= bx && x <= bx + btnW() && y >= by && y <= by + btnH()) { gOpen = !gOpen; return true; }
    if (!gOpen) return false;
    std::lock_guard<std::mutex> lk(gMx);
    int rows = 1 + (int)gScripts.size();
    if (x < panX() || x > panX() + panW() || y < panY() || y > panY() + rows * rowH()) return false;
    int row = (int)((y - panY()) / rowH());
    if (row == 0) gRescan = true;
    else { Script& s = gScripts[row - 1]; s.wanted = !s.wanted; }
    return true;
}

static int32_t hookedGetEvent(AInputQueue* q, AInputEvent** ev) {
    int32_t r = origGetEvent(q, ev);
    if (r < 0 || !*ev) return r;
    if (AInputEvent_getType(*ev) != AINPUT_EVENT_TYPE_MOTION) return r;
    int act = AMotionEvent_getAction(*ev) & AMOTION_EVENT_ACTION_MASK;
    float x = AMotionEvent_getX(*ev, 0), y = AMotionEvent_getY(*ev, 0);
    if (act == AMOTION_EVENT_ACTION_DOWN && handleTap(x, y)) gConsuming = true;
    if (gConsuming) {
        if (act == AMOTION_EVENT_ACTION_UP || act == AMOTION_EVENT_ACTION_CANCEL) gConsuming = false;
        AInputQueue_finishEvent(q, *ev, 1);
        return -1;  // событие съедено меню
    }
    return r;
}

// ---------------------------------------------------------------- установка хуков
static void* installThread(void*) {
    void* h = nullptr;
    for (int i = 0; i < 600 && !h; i++) { h = dlopen(LIB, RTLD_NOW | RTLD_NOLOAD); if (!h) usleep(100000); }
    if (!h) { LOGI("libminecraftpe.so not found"); return nullptr; }
    sleep(2);  // дать игре закончить релокации

    gSetPos = (setpos_t)dlsym(h, "_ZN6Entity6setPosERK4Vec3");
    gGetPos = (getpos_t)dlsym(h, "_ZNK6Entity6getPosEv");
    gJump = (jump_t)dlsym(h, "_ZN6Player14jumpFromGroundEv");

    char* vt = (char*)dlsym(h, "_ZTV11LocalPlayer");
    if (vt) {
        // vtable[31] (normalTick) = _ZTV + 8 + 31*4. Проверено по релокациям: 0x236a9e4 - 0x236a960 = 0x84
        void** slot = (void**)(vt + 0x84);
        if (unprotect(slot)) { origTick = (tick_t)*slot; *slot = (void*)hookedTick; LOGI("tick hook ok"); }
    } else LOGI("_ZTV11LocalPlayer not found");

    origSwap = (swap_t)patchGot("eglSwapBuffers", (void*)hookedSwap);
    origGetEvent = (getev_t)patchGot("AInputQueue_getEvent", (void*)hookedGetEvent);
    LOGI("swap=%p input=%p", origSwap, origGetEvent);
    return nullptr;
}

__attribute__((constructor)) static void onLoad() {
    pthread_t t; pthread_create(&t, nullptr, installThread, nullptr); pthread_detach(t);
}
