# mcjsmenu для MCPE 1.1.5 (armeabi-v7a)

Нативный мод: кнопка "JS" в левом верхнем углу -> список скриптов из
/sdcard/games/com.mojang/mcjs/*.js, тап включает/выключает, "RELOAD LIST" пересканирует папку.

## Что нужно
1. Android NDK (r21-r25) и исходники QuickJS в jni/quickjs/
2. patchelf (или MT Manager: добавить зависимость в libminecraftpe.so)

## Сборка и установка
    cd mcjsmenu && ndk-build
    # libs/armeabi-v7a/libmcjsmenu.so -> в APK: lib/armeabi-v7a/
    sh patch.sh   (patchelf --add-needed libmcjsmenu.so libminecraftpe.so)
    # пересобрать и подписать APK; скрипты положить в /sdcard/games/com.mojang/mcjs/

## JS API
    log(text)                 // logcat, тег mcjsmenu
    registerTick(fn)          // fn вызывается каждый тик игры (20 раз/с)
    player.getPos() -> [x,y,z]
    player.setPos(x,y,z)
    player.jump()

## Как это работает (найдено в вашей libminecraftpe.so)
- 32-bit ARM, не стрипнутые экспорты (63k символов): функции берутся через dlsym по именам.
- Тик: vtable LocalPlayer[31] = _ZN11LocalPlayer10normalTickEv (подмена слота, inline-хук не нужен).
- Рисование: GOT-хук eglSwapBuffers. Ввод: GOT-хук AInputQueue_getEvent.

## Что проверить на устройстве
- getPos/setPos используют _ZNK6Entity6getPosEv / _ZN6Entity6setPosERK4Vec3; если getPos
  вернёт мусор, значит сигнатура возврата другая — смотрите logcat и правьте js_getPos.
- Если меню не рисуется, игра может использовать другой GL-контекст: проверьте logcat
  "swap=... input=..." (оба указателя должны быть не нулевыми).
- Использовать только в одиночной игре (на серверах/Realms это бан).
